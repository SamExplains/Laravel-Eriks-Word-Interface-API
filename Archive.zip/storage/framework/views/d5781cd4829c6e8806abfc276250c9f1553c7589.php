<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">Dashboard</div>

                <div class="card-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>

                    You are logged in! <?php echo e(auth()->user()->name); ?>

                </div>
            </div>
        </div>

        
        <div class="col-12 mt-4">
            <div class="card">
              <div class="card-header">Word List

                <a href="<?php echo e(route('word.create')); ?>">
                  <button class="float-right btn btn-success">+ Add New Word</button>
                </a>

              </div>

                <div class="card-body">

                  <table class="table table-striped text-center">
                    <thead class="bg-light">
                    <tr>
                      <th scope="col">#</th>
                      <th scope="col">Date</th>
                      <th scope="col">Word</th>
                      <th scope="col">Edit</th>
                      <th scope="col">Delete</th>
                    </tr>
                    </thead>
                    <tbody>

                    <?php if(isset($words)): ?>
                      <?php $__currentLoopData = $words; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $word): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                          <th scope="row"><?php echo e($word->id); ?></th>
                          <td><?php echo e($word->longdate); ?></td>
                          <td><?php echo e($word->word); ?></td>
                          <td>
                            <a href="<?php echo e(route('word.edit', $word)); ?>">
                              <button class="btn btn-primary">Edit</button>
                            </a>
                          </td>
                          <td>
                            <form action="<?php echo e(route('word.destroy', [$word->id] )); ?>" method="post">
                              <?php echo method_field('DELETE'); ?>
                              <?php echo csrf_field(); ?> 
                              <button type="submit" class="btn btn-danger" onclick="confirm('Are you sure?')">Delete</button>
                            </form>
                          </td>
                        </tr>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                      <?php else: ?>

                      <div class="alert-danger p-2">
                        No words found!
                      </div>

                    <?php endif; ?>

                    </tbody>
                  </table>

                </div>
            </div>
        </div>

    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/Sam/Documents/Github Local/EriksWordRestAPI/resources/views/home.blade.php ENDPATH**/ ?>