<?php $__env->startSection('content'); ?>

<div class="container">
  <h4>Add New Word</h4>
  <div class="row">

    <?php if(session()->has('message')): ?>
    <div class="col-8 mx-auto alert-warning p-2 mb-2">
      Warning! <?php echo e(session()->get('message')); ?>

    </div>
    <?php endif; ?>

    <?php if(session()->has('success')): ?>
    <div class="col-8 mx-auto alert-success p-2 mb-2">
      Success! <?php echo e(session()->get('success')); ?>

    </div>
    <?php endif; ?>

    <div class="col-8 mx-auto">
      <a href="<?php echo e(route('home')); ?>">
        Back
      </a>
    </div>

    <div class="col-8 mx-auto mt-4">
      <form method="POST" action="<?php echo e(route('word.store')); ?>">
        <?php echo csrf_field(); ?>
        <div class="form-group">
          <label for="longdate">Date</label>
          <input type="text" class="form-control bg-white" name="longdate" id="longdate" placeholder="YYYY-MM-DD" value="<?php echo e(old('longdate')); ?>">
        </div>
        <div class="form-group">
          <label for="word">Word</label>
          <input type="text" class="form-control" name="word" id="word" aria-describedby="Word" value="<?php echo e(old('word')); ?>">
        </div>
        <button type="submit" class="btn btn-primary">Create</button>
      </form>
    </div>
  </div>
</div>

<script>
  /* Flatpickr Date/Time Selector */
  $('#longdate').flatpickr({dateFormat: "Y-m-d" });
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/Sam/Documents/Github Local/EriksWordRestAPI/resources/views/word/_create.blade.php ENDPATH**/ ?>