<?php $__env->startSection('content'); ?>

  <div class="container">
    <h4>Edit Word</h4>
    <div class="row">

      <?php if(session()->has('success')): ?>
          <div class="col-8 mx-auto alert-success p-2 mb-2">
            Success! <?php echo e(session()->get('success')); ?>

          </div>
      <?php endif; ?>

      <div class="col-8 mx-auto">
        <a href="<?php echo e(route('home')); ?>">
          Back
        </a>
      </div>

      <div class="col-8 mx-auto mt-4">
        <div class="dropdown">
          <button class="btn btn-dark dropdown-toggle" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
            Switch to another word
          </button>
          <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
            <?php $__currentLoopData = $words; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $w): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <a class="dropdown-item mb-3 mt-3" href="<?php echo e(route('word.edit', $w->id)); ?>"><span class="alert-primary p-2"><?php echo e($w->longdate); ?></span> : <b><?php echo e($w->word); ?></b></a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </div>
        </div>
      </div>

      <div class="col-8 mx-auto mt-4">
        <form method="POST" action="<?php echo e(route('word.update', $word->id)); ?>">
          <?php echo csrf_field(); ?>
          <?php echo method_field('PUT'); ?>
          <div class="form-group">
            <label for="longdate">Date</label>
            <input type="text" class="form-control bg-white" name="longdate" id="longdate" placeholder="YYYY-MM-DD" value="<?php echo e(($word->longdate) ? $word->longdate : old('longdate')); ?>">
          </div>
          <div class="form-group">
            <label for="word">Word</label>
            <input type="text" class="form-control" name="word" id="word" aria-describedby="Word" placeholder="<?php echo e($word->word); ?>" value="<?php echo e(($word->word) ? $word->word : old('word')); ?>">
          </div>
          <button type="submit" class="btn btn-primary">Update</button>
        </form>
      </div>
    </div>
  </div>

  <script>
    /* Flatpickr Date/Time Selector */
    $('#longdate').flatpickr({dateFormat: "Y-m-d" });
  </script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/Sam/Documents/Github Local/EriksWordRestAPI/resources/views/word/_edit.blade.php ENDPATH**/ ?>